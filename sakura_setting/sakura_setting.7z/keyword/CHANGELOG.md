# 変更履歴

## 2021-12-09
* ヘルプファイルで「\n\n」以降の文字列が正しく表示されない件を修正。
* イベント関連を別ファイルにした。

## 2016-11-28
* DeviceOrientationEvent、DeviceMotionEvent 追加。

## 2016-11-20
* Boolean、Event 関連追加。
* true、false 追加。
* イベントリファレンスのイベント追加。

## 2016-11-11
* API関連キーワード追加。
Console、Window、Document、Element、Screen、Navigator、EventTarget、Storage、Geolocation、Coordinates、NavigatorGeolocation、Position
* 必要そうなものだけ優先してヘルプを作成。

## 2016-11-08
* 標準オブジェクト関連追加。
Number、Math、Date、String、RegExp、Array、ArrayBuffer、JSON

## 2016-10-27
* 文と宣言、式と演算子など基本的なものから初版作成。
